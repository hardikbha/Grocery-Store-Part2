import home from './components/home.js'
import profile from './components/profile.js'
import login from './components/login.js'
import AdminDashboard from './components/AdminDashboard.js'
import ManagerDashboard from './components/ManagerDashboard.js'
import UserDashboard from './components/UserDashboard.js'
import register from './components/register.js'

const routes = [{ path: '/', component: home},

 {path: '/profile', component: profile},
 {path:"/user_dashboard",component:UserDashboard},
 {path:"/admin_dashboard",component:AdminDashboard},
 {path:"/manager_dashboard",component:ManagerDashboard},

{path: '/login', component: login},
{path:"/register",component:register}]
     
const router = new VueRouter({
    routes
  })

const app = new Vue({
    el: "#app",
    router: router,
    methods:{
      async logout(){
        const res=await fetch("/logout")
        if (res.ok){
          localStorage.clear()
          this.$router.push("/")
        }else{
          console.log("could not logout the user")
        }
      }
    }
})